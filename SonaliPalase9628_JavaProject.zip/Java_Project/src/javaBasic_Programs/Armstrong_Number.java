package javaBasic_Programs;

import java.util.Scanner;

public class Armstrong_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=scan.nextInt();
		int sum=0;
		int temp=n;
		int r;
		 while(n>0)
		 {
			 r=n%10;
			 sum=sum+(r*r*r);
			 n=n/10;
		 }
		 if(temp==sum)
		 {
			 System.out.println("Armstrong");
		 }
		 else
		 {
			 System.out.println("Not an Armstrong");
		 }

	}

}
