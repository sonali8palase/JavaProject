package javaBasic_Programs;

import java.util.Scanner;

public class CountofSameCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a String:");
		String s=scan.next();
	
		char[] ch=s.toCharArray();
		for(int i=0;i<=ch.length-1;i++)
		{
			int count=1;
			for(int j=i+1;j<=ch.length-1;j++)
			{
				if(ch[i]==ch[j]&&ch[i]!='0'&&ch[j]!='0')
				{
					count++;
					ch[j]='0';
				}
			}
			if(ch[i]!='0'&&ch[i]!=' ')
			{
				System.out.println(ch[i]+"="+count);
			}


		}

	}
}



