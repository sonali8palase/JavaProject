package javaBasic_Programs;

import java.util.Scanner;

public class EvenorOdd_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a Number");
		int num=scan.nextInt();
		
		if(num%2==0)
		{
			System.out.println(num+"="+"Even Number");
		}
		else
		{
			System.out.println(num+"="+"Odd Number");
		}


	}

}
