package javaBasic_Programs;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a Number:");
		int n=scan.nextInt();
		int temp=n;
		int rev=0;
		int rem=0;
		while(temp!=0)
		{
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
		}
		if(n==rev)
		{
			System.out.println(n+":\tPalindrome Number");
		}
		else
		{
			System.out.println(n+":\tNot Palindrome Number");
		}

	}

}
