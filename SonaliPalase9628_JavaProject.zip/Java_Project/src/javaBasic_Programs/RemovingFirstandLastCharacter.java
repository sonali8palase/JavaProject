package javaBasic_Programs;

import java.util.Scanner;

public class RemovingFirstandLastCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="EduBridge";
		System.out.println(removeFirstAndLast(s));
	}
	public static String removeFirstAndLast(String s)
	{
		s=s.substring(1, s.length()-1);
		return s;
	}

}
