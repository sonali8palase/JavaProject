package javaBasic_Programs;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a Number");
		int n=scan.nextInt();
		int d;
		int sum=0;
		while(n!=0)
		{
			d=n%10;
			sum=sum*10+d;
			n=n/10;
		}
		System.out.println(sum);
		

	}

}
