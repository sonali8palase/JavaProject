package javaBasic_Programs;

public class Reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//way1:
		String s="saiprasanna";
		String rev="";
		
		int len=s.length();//11
		
		for(int i=len-1;i>=0;i--) //10 9 8 7 6 5 4 3 2 1 0
		{
			rev=rev+s.charAt(i); //annasarpias
		}
		System.out.println(rev); 
		
		//way2:
		/*String s="saiprasanna";
		String rev="";
		char a[]=s.toCharArray();
		int len=s.length();
		
		for(int i=len-1;i>=0;i--)
		{
			rev=rev+a[i];
		}
		System.out.println(rev);*/
		
		//way3:
		/*StringBuffer sb=new StringBuffer(s);
		System.out.println(sb.reverse());*/
		
	}

}
