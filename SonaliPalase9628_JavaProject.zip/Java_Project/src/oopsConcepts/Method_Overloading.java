package oopsConcepts;
        //The process defining class by same method name but different parameters is called Method overloading.
		//it is also called as complietime polymorphism.
public class Method_Overloading {
	void add(int x, int y)
	{
		System.out.println("Add:"+(x+y));
	}
	void add(int x,int y,int z)
	{
		System.out.println("Add:"+(x+y+z));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Method_Overloading m=new Method_Overloading();
		m.add(10,20);
		m.add(10,20,30);

	}

}
