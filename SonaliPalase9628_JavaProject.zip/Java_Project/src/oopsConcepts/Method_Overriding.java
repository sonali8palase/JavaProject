package oopsConcepts;

		class Parent2
		{
			public void name()
			{
				System.out.println("Earla saiprasanna");
			}
		}
		class Child2 extends Parent2
		{
			public void course()
			{
				super.name();
				System.out.println("Software Testing");
			}
		}
        //The process defining class by same method name but different method body is called method overriding.
		//it is also called as rumtime polymorphism.
		public class Method_Overriding {

			public static void main(String[] args) {
				Child2 c=new Child2();
				

				c.course();
			}
				
	}


